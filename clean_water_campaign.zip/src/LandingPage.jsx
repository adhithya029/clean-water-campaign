import React from "react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-50 via-white to-sky-50 text-gray-900">
      {/* Hero Section */}
      <section className="text-center py-20">
        <h1 className="text-4xl font-extrabold text-sky-700">Water = Life</h1>
        <p className="mt-4 text-lg text-slate-700">
          Every family deserves access to clean drinking water. Join us to make a difference.
        </p>
        <div className="mt-6 flex justify-center gap-4">
          <a href="#donate" className="px-6 py-3 rounded-xl bg-sky-600 text-white shadow hover:bg-sky-700">💧 Donate Now</a>
          <a href="#volunteer" className="px-6 py-3 rounded-xl border border-sky-600 text-sky-700 hover:bg-sky-50">🤝 Volunteer</a>
        </div>
      </section>
    </div>
  );
}
